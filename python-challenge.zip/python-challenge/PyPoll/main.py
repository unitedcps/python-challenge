import os
import csv
import pandas as pd
import numpy as np

census_csv = os.path.join("/Users/sunflower/PycharmProjects/pythonProject/04Python/PyPoll/election_data.csv")
results = pd.read_csv('/Users/sunflower/PycharmProjects/pythonProject/04Python/PyPoll/election_data.csv', index_col=0)


print(results)


total_votes=len(results.index)
print(total_votes)

candidate_tot = results.value_counts(["Candidate"])

print(candidate_tot)

final_results= candidate_tot/total_votes *100

final_final_results =print(final_results.round(3))

print("Winner Diana DeGette")




